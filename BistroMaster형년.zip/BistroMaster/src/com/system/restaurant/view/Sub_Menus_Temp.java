package com.system.restaurant.view;

public class Sub_Menus_Temp {

	public static void makeSubTitle(String text, int num) {
		Templates.printThickTextBox(text, num, 0);
	}
	
	public static void makeSubCategory(String text, int num) {
		Templates.printThickTextBox(text, num, 3);
	}
}
