package com.system.restaurant.view;

public class OrderView {
	public static void showOrder() {
		System.out.println();
	}
}
