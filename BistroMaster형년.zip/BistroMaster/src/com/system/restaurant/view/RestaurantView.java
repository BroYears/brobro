package com.system.restaurant.view;

public class RestaurantView {

	public void startDay() {
		
	}
	
	public void endDay() {
	

	}
	
	public void endMonth() {

	}
	
	
	
}
