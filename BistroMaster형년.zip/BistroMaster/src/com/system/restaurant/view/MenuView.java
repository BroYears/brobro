package com.system.restaurant.view;

public class MenuView {
	public static void main(String[] args) {
		showMenu();
	}
	public static void showMenu() {
		No5Menu.loadNum5();
	}
}
