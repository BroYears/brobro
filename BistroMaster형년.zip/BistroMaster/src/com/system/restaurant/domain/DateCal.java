package com.system.restaurant.domain;

public class DateCal {
	private String today;

	public DateCal(String today) {
		this.today = today;
	}

	public String getToday() {
		return today;
	}
}
