package com.system.restaurant.domain;

public class Food {
	
	public Food() {
		
		
	}
	
}
