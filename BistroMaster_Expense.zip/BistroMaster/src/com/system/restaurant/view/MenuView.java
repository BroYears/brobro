package com.system.restaurant.view;

public class MenuView {

	private String ingredient;
	private String drink;
	private int ea;
	private String tableNo;
	
	
}
