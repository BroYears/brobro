package com.system.restaurant.view;

public class ReservationView {

	private int no;
	private String name;
	private String Phonumber;
	private String datetime;
	private int number;
	
}
