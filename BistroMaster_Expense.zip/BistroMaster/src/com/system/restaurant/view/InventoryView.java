package com.system.restaurant.view;

public class InventoryView {

}
