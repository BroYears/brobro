package com.system.restaurant.employee;

public class Employee extends User{

	private int attendance;
	private String type;
}
