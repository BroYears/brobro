package com.system.restaurant.employee;

public abstract class User {

	private int no;
	private String name;
	private String phoneNumber;
	private String hireDate;
	private int payment;
	
	public void showAttendance() {
		
	}
	
}
