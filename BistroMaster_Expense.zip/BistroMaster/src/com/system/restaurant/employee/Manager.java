package com.system.restaurant.employee;

public class Manager extends User {

	private int attendance;
	
}
