package com.system.restaurant.employee;

public class Admin {

	public void foodCal() {
		
	}
	
	private void settingEmployee(User u) {
		
	}
	
}
