package com.system.restaurant.employee;

public class EmployeeService {

}
