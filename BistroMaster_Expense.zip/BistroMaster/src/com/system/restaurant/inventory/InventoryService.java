package com.system.restaurant.inventory;

public class InventoryService {

}
