package com.system.restaurant.inventory;

public class Inventory {

	private String name;
	private int quantity;
	private int price;
	private int expiryDate;

}
