package com.system.restaurant.repository;

public class RestaurantDAO {

	public void load() {
		
	}
	
	public void save() {
		
	}
	
	
	
}
