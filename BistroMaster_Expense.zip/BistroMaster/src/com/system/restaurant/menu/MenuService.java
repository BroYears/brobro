package com.system.restaurant.menu;

public class MenuService {

}
