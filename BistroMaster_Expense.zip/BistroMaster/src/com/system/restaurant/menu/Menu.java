package com.system.restaurant.menu;

public class Menu {

	private String ingredient;
	private String drink;
	private int quantity;
	
	
}
