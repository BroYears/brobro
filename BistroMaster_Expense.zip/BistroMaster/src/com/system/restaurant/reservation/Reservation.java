package com.system.restaurant.reservation;

public class Reservation {

	private int no;
	private String name;
	private String phoneNumber;
	private String dateTime;
	private int number;
	
}
